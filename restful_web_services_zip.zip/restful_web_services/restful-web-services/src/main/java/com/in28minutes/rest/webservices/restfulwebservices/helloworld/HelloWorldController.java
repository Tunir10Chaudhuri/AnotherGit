package com.in28minutes.rest.webservices.restfulwebservices.helloworld;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.Locale;

import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.web.bind.annotation.PathVariable;

@RestController
public class HelloWorldController
{
	private MessageSource ms;
	public HelloWorldController(MessageSource ms)
	{
		this.ms=ms;
	}
	@RequestMapping(method=RequestMethod.GET, path="/helloworld")
	public String helloworld()
	{
		Locale locale=LocaleContextHolder.getLocale();
		return ms.getMessage("hello.world.message", null, "Default Message", locale);
	}
	@RequestMapping(method=RequestMethod.GET, path="/helloworldbean")
	public HelloWorldBean helloworldbean()
	{
		return new HelloWorldBean("Hello World!");
	}
	@RequestMapping(method=RequestMethod.GET, path="/helloworld/pathvariable/{name}")
	public HelloWorldBean helloworldpathvariable(@PathVariable String name)
	{
		return new HelloWorldBean("Hello World! "+name);
	}
	
}