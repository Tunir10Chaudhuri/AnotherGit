package com.in28minutes.rest.webservices.restfulwebservices.user;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.http.ResponseEntity.BodyBuilder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import jakarta.validation.Valid;

@RestController
public class UserResource
{
    private UserDaoService service;	
    public UserResource(UserDaoService service)
    {
    	this.service=service;
    }
	
    @GetMapping("/users")
	public List<User> retrieveAllUsers()
	{
    	return service.findAll();
	}
    
    @GetMapping("/user/{id}")
	public EntityModel<User> retrieveUser(@PathVariable int id)
	{
    	if(service.findOne(id)==null)
    	{
    		throw new UserNotFoundException("id:");
    	}
    	EntityModel<User> em=EntityModel.of(service.findOne(id));
    	WebMvcLinkBuilder link=linkTo(methodOn(this.getClass()).retrieveAllUsers());
    	em.add(link.withRel("all-users"));
    	return em;
	}
    
    @PostMapping("/userpost")
    public void createUser(@Valid @RequestBody User user)
    {
    	service.save(user);
    }
    
    @DeleteMapping("/userd/{id}")
	public void deleteUser(@PathVariable int id)
	{
    	service.delete(id);
	}
}