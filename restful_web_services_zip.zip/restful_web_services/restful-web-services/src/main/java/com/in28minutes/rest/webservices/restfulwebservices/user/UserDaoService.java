package com.in28minutes.rest.webservices.restfulwebservices.user;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class UserDaoService
{
	private static List<User> users=new ArrayList<>();
	
	static
	{
		users.add(new User(1,"Abc"));
		users.add(new User(2,"Def"));
	}
	
	public List<User> findAll()
	{
		return users;
	}

	public User findOne(int id) {
		for(User u:users)
		{
			if (u.getId()==id)
				return u;
		}
		return null;
	}
	
	public void save(User user)
	{
		users.add(user);
	}

	public void delete(int id) {
		for(User u:users)
		{
			if (u.getId()==id)
				users.remove(u);
		}
	}


	
}