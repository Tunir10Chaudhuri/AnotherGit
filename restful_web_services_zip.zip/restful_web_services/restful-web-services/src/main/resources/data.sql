insert into user_details(id,name)
values(101,'User1');

insert into user_details(id,name)
values(102,'User2');

insert into user_details(id,name)
values(103,'User3');

insert into post(id,description,user_id)
values(201,'I am the first user',101);

insert into post(id,description,user_id)
values(202,'I am the second user',102);

insert into post(id,description,user_id)
values(203,'I am the third user',103);
